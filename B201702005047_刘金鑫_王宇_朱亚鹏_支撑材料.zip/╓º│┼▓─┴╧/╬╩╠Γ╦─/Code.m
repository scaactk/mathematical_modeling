clear;clc;
A=load('form.txt');
num = size(A); % ��������;
within = 0.00000015;

for i = 1:num(1)
    A(i,3) = 999999999;
end

for i = 1:num(1)
    for j = 1:num(1)
        if(j == i)
            continue;
        else
            temp = (A(i,1) - A(j,1))^2 + (A(i,2) - A(j,2))^2;
            if(temp < A(i,3))
                A(i,3) = temp;
            end
        end
    end
end