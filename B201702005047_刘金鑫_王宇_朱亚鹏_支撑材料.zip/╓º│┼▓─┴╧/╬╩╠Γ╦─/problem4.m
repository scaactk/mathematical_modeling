clear; 
target = 'target.xlsx';
t = xlsread(target);
t1 = t(:,1);
t2 = t(:,2);

user = 'user.xlsx';
u = xlsread(user);
u1 = u(:,1);
u2 = u(:,2);
u3 = u(:,3);

count = zeros(2066,1);

for i=1:2066 %����
    for j=1:351 %�û�
        dis = (t1(i)-u1(j)).^2 *111*111*0.847329 + (t2(i)-u2(j)).^2*111*111;
        if dis<6.25
            count(i)= count(i)+1;
        end
    end
end




