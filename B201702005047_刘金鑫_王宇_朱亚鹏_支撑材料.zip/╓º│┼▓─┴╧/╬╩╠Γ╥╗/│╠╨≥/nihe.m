clear; 
target = 'target.xlsx';
t = xlsread(target);
t1 = t(:,1);
t2 = t(:,2);
t3 = t(:,3);

user = 'user.xlsx';
u = xlsread(user);
u1 = u(:,1);
u2 = u(:,2);
u3 = u(:,3);

count = zeros(835,1);

for i=1:835 %����
    for j=1:351 %�û�
        dis = (t1(i)-u1(j)).^2 *111*111*0.847329 + (t2(i)-u2(j)).^2*111*111;
        if dis<6.25
            count(i)= count(i)+1;
        end
    end
end

ave = zeros(23,1);
temp = 0;
for i=(temp+1):temp+65
    ave(1) = ave(1) + count(i);
end
ave(1) = ave(1)/65;
temp = temp+65;

for i=(temp+1):temp+150
    ave(2) = ave(2) + count(i);
end
ave(2) = ave(2)/150;
temp = temp+150;

for i=(temp+1):temp+103
    ave(3) = ave(3) + count(i);
end
ave(3) = ave(3)/103;
temp = temp+103;

for i=(temp+1):temp+63
    ave(4) = ave(4) + count(i);
end
ave(4) = ave(4)/63;
temp = temp+63;

for i=(temp+1):temp+38
    ave(5) = ave(5) + count(i);
end
ave(5) = ave(5)/38;
temp = temp+38;

for i=(temp+1):temp+23
    ave(6) = ave(6) + count(i);
end
ave(6) = ave(6)/23;
temp = temp+23;

for i=(temp+1):temp+30
    ave(7) = ave(7) + count(i);
end
ave(7) = ave(7)/23;
temp = temp+30;

for i=(temp+1):temp+11
    ave(8) = ave(8) + count(i);
end
ave(8) = ave(8)/11;
temp = temp+11;

for i=(temp+1):temp+19
    ave(9) = ave(9) + count(i);
end
ave(9) = ave(9)/19;
temp = temp+19;

for i=(temp+1):temp+8
    ave(10) = ave(10) + count(i);
end
ave(10) = ave(10)/8;
temp = temp+8;

for i=(temp+1):temp+96
    ave(11) = ave(11) + count(i);
end
ave(11) = ave(11)/96;
temp =  temp+96;

for i=(temp+1):temp+11
    ave(12) = ave(12) + count(i);
end
ave(12) = ave(12)/23;
temp = temp+11;

for i=(temp+1):temp+4
    ave(13) = ave(13) + count(i);
end
ave(13) = ave(13)/4;
temp = temp+4;

for i=(temp+1):temp+5
    ave(14) = ave(14) + count(i);
end
ave(14) = ave(14)/23;
temp = temp+5;

for i=(temp+1):temp+60
    ave(15) = ave(15) + count(i);
end
ave(15) = ave(15)/60;
temp = temp+60;

for i=(temp+1):temp+9
    ave(16) = ave(16) + count(i);
end
ave(16) = ave(16)/9;
temp = temp+9;

for i=(temp+1):temp+10
    ave(17) = ave(17) + count(i);
end
ave(17) = ave(17)/10;
temp = temp+10;

for i=(temp+1):temp+5
    ave(18) = ave(18) + count(i);
end
ave(18) = ave(18)/5;
temp = temp+5;

for i=(temp+1):temp+5
    ave(19) = ave(19) + count(i);
end
ave(19) = ave(19)/5;
temp = temp+5;

for i=(temp+1):temp+2
    ave(20) = ave(20) + count(i);
end
ave(20) = ave(20)/2;
temp = temp+2;

for i=(temp+1):temp+78
    ave(21) = ave(21) + count(i);
end
ave(21) = ave(21)/23;
temp = temp+78;

for i=(temp+1):temp+13
    ave(22) = ave(22) + count(i);
end
ave(22) = ave(22)/13;
temp = temp+13;

for i=(temp+1):temp+27
    ave(23) = ave(23) + count(i);
end
ave(23) = ave(23)/27;
temp = temp+27;

ls = [65
65.5
66
66.5
67
67.5
68
68.5
69
69.5
70
70.5
71
71.5
72
72.5
73
73.5
74
74.5
75
80
85];

price = zeros(835,1);
ave_price = 0;
for i=1:835
    price(i)=8.98/count(i) +62;
    ave_price = ave_price + price(i);
end
ave_price = ave_price/835